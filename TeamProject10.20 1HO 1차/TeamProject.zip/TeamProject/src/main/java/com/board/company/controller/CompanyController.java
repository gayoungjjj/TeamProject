package com.board.company.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.board.company.mapper.CompanyMapper;
import com.board.company.vo.CompanyVo;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
/* 기능 구현
1. 로그인할때 db에서 id, 암호 확인하는 것
2. 로그인 후 기업_메인화면으로 이동하게 하는 것  */
@Controller
@RequestMapping("/Company")
public class CompanyController {
	
	@Autowired
	private CompanyMapper companyMapper;
	
	// Company/Login
	@GetMapping("/Login")
	public String login() {
		return "company/login";
	}
	
	
	@RequestMapping("/Login")
	public String login(
	HttpServletRequest request,
	HttpServletResponse response
	){
	String cuserid = request.getParameter("cuserid");
	String cpasswd = request.getParameter("cpasswd");
	
	CompanyVo vo = companyMapper.login(cuserid,cpasswd);
	
	HttpSession  session = request.getSession();
	session.setAttribute("login", vo );
	
	 return "redirect:/company/main";
	 
    }

	
	
	
	// Company/Main
	@RequestMapping("/Main")
	public String main() {
		return "company/main" ;
	}
	
	
	@RequestMapping(value="/Logout",
			method = RequestMethod.GET)
		public   String   logout(
			HttpServletRequest    request,
			HttpServletResponse   response,
			HttpSession           session
				) {
			
			//Object url = session.getAttribute("URL");
			session.invalidate();
			
			//return "redirect:" + (String) url;
			return  "redirect:/";
		}
		
	
	
	
	
}
