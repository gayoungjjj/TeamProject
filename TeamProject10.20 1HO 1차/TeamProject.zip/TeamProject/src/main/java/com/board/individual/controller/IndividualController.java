package com.board.individual.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.board.company.mapper.CompanyMapper;
import com.board.company.vo.CompanyVo;
import com.board.individual.mapper.IndividualMapper;
import com.board.individual.vo.IndividualVo;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/Individual")
public class IndividualController {
	
	@Autowired
	private IndividualMapper individualMapper;
	
	@GetMapping("/Login")
	public String login() {
		return "individual/login";
	}
	
	// Individual/Login
	@RequestMapping("/Login")
	public String login( 
		HttpServletRequest request,
		HttpServletResponse response
		){
		String iuserid = request.getParameter("iuserid");
		String ipasswd = request.getParameter("ipasswd");
		
		IndividualVo vo = individualMapper.login(iuserid,ipasswd);
		System.out.println(vo);
		
		HttpSession  session = request.getSession();
		session.setAttribute("login", vo );
		
		 return "redirect:/individual/main";
	}
		
	// Individual/Main
	@RequestMapping("/Main")
	public String main() {
		return "individual/main" ;
	}
	
	
	
	@RequestMapping(value="/Logout",
			method = RequestMethod.GET)
		public   String   logout(
			HttpServletRequest    request,
			HttpServletResponse   response,
			HttpSession           session
				) {
			
			//Object url = session.getAttribute("URL");
			session.invalidate();
			
			//return "redirect:" + (String) url;
			return  "redirect:/";
		}
		
	
	
}