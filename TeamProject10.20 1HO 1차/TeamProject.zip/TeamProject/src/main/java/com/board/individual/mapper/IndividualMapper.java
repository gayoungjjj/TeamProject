package com.board.individual.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.board.individual.vo.IndividualVo;

@Mapper
public interface IndividualMapper {

	IndividualVo login(String iuserid, String ipasswd);

}
