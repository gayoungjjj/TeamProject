package com.board.company.vo;

import lombok.Data;

@Data
public class CompanyVo {

}
