package com.board.company.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CompanyMapper {

}
