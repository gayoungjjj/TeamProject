package com.board.individual.vo;

import lombok.Data;

@Data
public class IndividualVo {

}
